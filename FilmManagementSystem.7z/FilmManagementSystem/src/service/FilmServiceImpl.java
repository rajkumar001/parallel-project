package com.capgemini.film.service;

import java.util.List;


import com.capgemini.film.poso.Actor;
import com.capgemini.film.poso.Film;
import com.capgemini.film.repository.IFilmRepository;



public class FilmServiceImpl implements IFilmService  {
	
	private IFilmRepository fr;
	

	public FilmServiceImpl() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FilmServiceImpl(IFilmRepository fr) {
		super();
		this.fr = fr;
	}

	public String addFilm(Film film) {
		// TODO Auto-generated method stub
		Film f=film;
		if(f==null)
		{
			throw new NullPointerException();
		}
		else 
		{
			
			if(f.getTitle()==null)throw new IllegalArgumentException();
			if(f.getDescription()==null)throw new IllegalArgumentException();
			if(f.getReleaseYear()==0)throw new IllegalArgumentException();
			if(f.getAlbum()==null)throw new IllegalArgumentException();
			if(f.getLanguage()==null)throw new IllegalArgumentException();
			if(f.getActor()==null)throw new IllegalArgumentException();
			if(f.getCategory()==null)throw new IllegalArgumentException();
			if(f.getRating()<1 || f.getRating()>6)throw new IllegalArgumentException();
			if(f.getDeleteDate()==null)throw new IllegalArgumentException();
			if(f.getLength()<0)throw new IllegalArgumentException();
			if(f.getCreateDate()==null)throw new IllegalArgumentException();
			try{
			fr.save(f);
			return "successfull";
			}
			catch(Exception e)
			{
				return "fail";
			}
		}
		
	}

	public String modifyFilm(Film film) {
		// TODO Auto-generated method stub
		if(film==null)
		{
			throw new NullPointerException();
		}
		try{
			
	
		if(fr.modifyFilm(film))
		{
			System.out.println("s");
			return "succesfull";
		}
			}
		 catch(Exception e)
		{
			 System.out.println("f1");
				return "failed";
		}
		return "failed";
	}

	public String deleteFilm(Film film) {
		// TODO Auto-generated method stub
		if(film==null)
		{
			throw new NullPointerException();
		}
		try{
		if(fr.deleteFilm(film))
			return "succesfull";
		
		return "falied";
		}
		 catch(Exception e)
		{
			 
				return "System Error";
		}
	
	}

	public List<Film> searchFilmByTitle(String title) {
		// TODO Auto-generated method stub
		List<Film> film=null;
		if(title==null)
		{
			throw new NullPointerException();
		}
		try{
			 film=fr.searchFilmByTitle(title);
			
		}
		catch(Exception e){return null;}
		
		if(film.isEmpty())
		{
			return null;
		}
		return  film;
	}

	public List<Film> searchFilmByCategory(String category) {
		// TODO Auto-generated method stub
		List<Film> film=null;
		if(category==null)
		{
			throw new NullPointerException();
		}
		try{
		 film=fr.searchFilmByCategory(category);
		}catch(Exception e){}
		if(film.isEmpty())
		{
			return null;
		}
		return  film;
	}

	public List<Film> searchFilmByRating(short rating) {
		// TODO Auto-generated method stub
		List<Film> film=null;
		if(rating==0)
		{
			throw new IllegalArgumentException();
		}
		try{
		 film=fr.searchFilmByRating(rating);
		}catch(Exception e)
		{
			
		}
		if(film.isEmpty())
		{
			return null;
		}
		return  film;
	}

	public List<Film> searchFilmByLanguage(String lang) {
		// TODO Auto-generated method stub
		List<Film> film=null;
		if(lang==null)
		{
			throw new NullPointerException();
		}
		try{
	 film=fr.searchFilmByLanguage(lang);
		}catch(Exception e)
		{}
		if(film.isEmpty())
		{
			return null;
		}
		return  film;
	}

	public List<Film> searchFilmByActor(Actor actor) {
		// TODO Auto-generated method stub
		List<Film> film=null;
		if(actor==null)
		{
			throw new NullPointerException();
		}
		try{
			film=fr.searchFilmByActor(actor);
		}
		 catch(Exception e)
		{}
		if(film.isEmpty())
		{
			return null;
		}
		return  film;
	}

	public List<Film> searchFilmByRealeaseYear(short year) {
		// TODO Auto-generated method stub
		List<Film> film=null;
		if(year==0)
		{
			throw new IllegalArgumentException();
		}
		try{
		 film=fr.searchFilmByRealeaseYear((short)year);
		}catch(Exception e){}
		if(film.isEmpty())
		{
			return null;
		}
		return  film;
	}

	
}
