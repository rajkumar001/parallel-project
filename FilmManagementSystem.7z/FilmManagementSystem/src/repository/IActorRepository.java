package com.capgemini.film.repository;

import java.util.List;

import com.capgemini.film.poso.Actor;



public interface IActorRepository {
	boolean save(Actor actor);
	List<Actor> searchByName(String firstName,String lastName);
	List<Actor> searchByGender(String Gender);
	boolean deleteActor(Actor actor);
	boolean modifyActor(Actor actor);
	
}
