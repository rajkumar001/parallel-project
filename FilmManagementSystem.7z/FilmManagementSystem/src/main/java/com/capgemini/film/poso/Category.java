package com.capgemini.film.poso;

import java.util.Date;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
@Entity
public class Category {
	@Id @GeneratedValue(strategy=GenerationType.IDENTITY)
	int id;
	String name;
	@ManyToMany(mappedBy="category")
	List<Film> film;
	Date createDate;
	Date deleteDate;
	
	
	public Category(int id, String name, List<Film> film, Date createDate, Date deleteDate) {
		super();
		this.id = id;
		this.name = name;
		this.film = film;
		this.createDate = createDate;
		this.deleteDate = deleteDate;
	}
	public Category(int id2, String name2, Object film2, Date createDate2, Date deleteDate2) {
		// TODO Auto-generated constructor stub
	}
	public void Category1(int id2, String name2, Object film2, Date createDate2, Date deleteDate2) {
		// TODO Auto-generated constructor stub
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getDeleteDate() {
		return deleteDate;
	}
	public void setDeleteDate(Date deleteDate) {
		this.deleteDate = deleteDate;
	}
	
	public List<Film> getFilm() {
		return film;
	}
	public void setFilm(List<Film> film) {
		this.film = film;
	}
	@Override
	public String toString() {
		return "Category [id=" + id + ", name=" + name + ", film=" + film + ", createDate=" + createDate
				+ ", deleteDate=" + deleteDate + "]";
	}
	
	

}
