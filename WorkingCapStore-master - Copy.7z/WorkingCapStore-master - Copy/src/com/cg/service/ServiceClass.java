package com.cg.service;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sun.misc.*;

import java.security.*;
import javax.crypto.*;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import com.cg.domain.Feedback;
import com.cg.domain.Merchant;
import com.cg.domain.Offer;
import com.cg.domain.Product;
import com.cg.domain.ProductSold;
import com.cg.domain.Stockscheme;
import com.cg.domain.User;
import com.cg.repository.IDaoFeedback;

import com.cg.repository.IDaoMerchant;
import com.cg.repository.IDaoOffer;
import com.cg.repository.IDaoUser;

import com.cg.repository.IDaoOrder;
import com.cg.repository.IDaoProduct;

@Service
public class ServiceClass {
	@Value("#{img['ipaddress2']}")
	String ipaddress;

	@Autowired
	public IDaoFeedback idaofeedback;

	@Autowired
	public IDaoMerchant idaomerchant;
	@Autowired
	public IDaoOffer idaooffer;
	@Autowired
	public IDaoOrder idaoorder;
	@Autowired
	public IDaoProduct idaoproduct;

	@Autowired
	public IDaoUser idaouser;
	@Autowired

	final String ALGO = "AES";
	final byte[] keyValue = new byte[] { 'T', 'h', 'e', 'B', 'e', 's', 't', 'S', 'e', 'c', 'r', 'e', 't', 'K', 'e',
			'y' };

	@Transactional
	public String encrypt(String Data) throws Exception {

		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.ENCRYPT_MODE, key);
		byte[] encVal = c.doFinal(Data.getBytes());
		String encryptedValue = new BASE64Encoder().encode(encVal);
		return encryptedValue;
	}

	@Transactional
	public String decrypt(String encryptedData) throws Exception {
		Key key = generateKey();
		Cipher c = Cipher.getInstance(ALGO);
		c.init(Cipher.DECRYPT_MODE, key);
		byte[] decordedValue = new BASE64Decoder().decodeBuffer(encryptedData);
		byte[] decValue = c.doFinal(decordedValue);
		String decryptedValue = new String(decValue);
		return decryptedValue;
	}

	@Transactional
	private Key generateKey() {
		Key key = new SecretKeySpec(keyValue, ALGO);
		return key;
	}

	@Transactional
	public boolean activateUser(String userid, Long ts) {
		boolean activated = false;
		Calendar cal = Calendar.getInstance();
		Long ts1 = cal.getTimeInMillis();
		Long time = (long) (24 * 60 * 60 * 1000);
		if ((ts1 - ts) <= time) {
			List<User> userList = new ArrayList<User>();
			userList = idaouser.findAll();
			Iterator<User> itr = userList.iterator();
			while (itr.hasNext()) {
				User user = new User();
				user = (User) itr.next();
				if (userid.equals(user.getUserId())) {
					user.setUserStatus("Active");
					idaouser.saveAndFlush(user);
					activated = true;
					break;
				}
			}
		}
		return activated;
	}

	@Transactional
	public boolean activateMerchant(String mer_id, Long ts) {
		boolean activated = false;
		Calendar cal = Calendar.getInstance();
		Long ts1 = cal.getTimeInMillis();
		Long time = (long) (24 * 60 * 60 * 1000);
		if ((ts1 - ts) <= time) {
			List<Merchant> merchantList = new ArrayList<Merchant>();
			merchantList = idaomerchant.findAll();
			Iterator<Merchant> itr = merchantList.iterator();
			while (itr.hasNext()) {
				Merchant merchant = new Merchant();
				merchant = (Merchant) itr.next();
				if (mer_id.equals(merchant.getMerchantId())) {
					merchant.setMerchantStatus("Active");
					idaomerchant.saveAndFlush(merchant);
					activated = true;
					break;
				}
			}
		}
		return activated;
	}

	private User u;
	private Merchant m;

	@Transactional
	public boolean validateLogin(HttpServletRequest req, String email_id, String user_password) {
		String s = null;
		String merchantname = null;

		u = idaouser.findById(email_id);

		if (u != null) {
			s = u.getUserId();
		} else if (u == null) {
			m = idaomerchant.findById(email_id);

			if (m != null) {
				s = m.getMerchantId();
				merchantname = m.getMerchantName();
			} else {
				return false;
			}
		}
		String pass = new String();
		try {
			pass = encrypt(user_password);
		} catch (Exception e) {
			e.printStackTrace();
		}
		char[] a;
		a = s.toCharArray();
		if (a[0] == 'C' && a[1] == '_') {
			String s2 = idaouser.getUserPassword(email_id);
			String s1 = idaouser.getUserStatus(email_id);
			if (s2.equals(pass) && s1.equalsIgnoreCase("active")) {
				String uid = idaouser.getUserId(email_id);
				String userName = idaouser.getUserName(email_id);
				HttpSession ses = req.getSession();
				ses.setAttribute("merchantid", uid);
				ses.setAttribute("userName", userName);
				return true;
			} else {
				return false;
			}
		} else if (a[0] == 'M' && a[1] == '_') {
			String s2 = idaomerchant.getMerchantPassword(email_id);
			String s1 = idaomerchant.getMerchantStatus(email_id);
			if (pass.equals(s2) && s1.equalsIgnoreCase("active")) {
				String mid = idaomerchant.getMerchantId(email_id);
				HttpSession ses = req.getSession();
				ses.setAttribute("merchantid", mid);
				ses.setAttribute("merchantname", merchantname);
				return true;
			} else {
				return false;
			}
		} else
			return false;
	}

	@Transactional
	public boolean createFeedback(String userid, String id, String feedback_content, double rating) {// REmoved
																										// USER_ID
																										// from
																										// fn

		Feedback fb = new Feedback();

		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
		Calendar cal = Calendar.getInstance();

		String date = dateFormat.format(cal.getTime());

		String d[] = date.split("/");
		int year = Integer.parseInt(d[0]) - 1900;

		int month = Integer.parseInt(d[1]) - 1;
		int day = Integer.parseInt(d[2]);
		Date requiredForm = new Date(year, month, day);

		fb.setFeedbackContent(feedback_content);
		fb.setFeedbackDate(requiredForm);

		fb.setId(id);
		fb.setRating(rating);
		fb.setType("user");

		User u = new User();
		u.setUserId(userid);

		fb.setUser(u);
		idaofeedback.save(fb);

		return true;

	}

	@Transactional
	public List<Feedback> getAll(String pid) {
		List<Feedback> fli = new ArrayList<Feedback>();
		fli = idaofeedback.findAll();

		List<Feedback> finalli = new ArrayList<Feedback>();
		for (Feedback f : fli) {

			if (f.getId().contains(pid)) {
				Feedback obj = new Feedback();
				obj.setFeedbackId(f.getFeedbackId());
				obj.setFeedbackContent(f.getFeedbackContent());
				obj.setFeedbackDate(f.getFeedbackDate());
				obj.setRating(f.getRating());
				obj.setId(f.getId());
				obj.setUser(f.getUser());
				finalli.add(obj);

			}
		}

		return finalli;
	}

	@Transactional
	public List<ProductSold> calculateProductDiscount(HttpSession session, HttpServletRequest request) {

		List<ProductSold> list_ps = new ArrayList<ProductSold>();

		/*
		 * session.setAttribute("productid", "1");
		 * session.setAttribute("userid", "1");
		 */
		String product = (String) session.getAttribute("productId");
		/* String user = (String) session.getAttribute("userid"); */
		String user = "C_1234";
		int qty = Integer.parseInt(request.getParameter("qty"));
		String scheme = (String) session.getAttribute("schemeId");
		/* String scheme = request.getParameter("schemeId"); */

		Product p_new = idaoproduct.findOne(product);
		ProductSold ps = new ProductSold();
		String Product_id = product;
		double actual_price = 0;
		String scheme_id = scheme;
		double price1 = p_new.getProductCost();

		if (scheme.equals("")) {

			actual_price = qty * price1;
			ps.setQty(qty);
			ps.setActual_price(actual_price);
		}

		else {

			Offer o = idaooffer.findScheme_id(Long.parseLong((scheme_id)));
			Product p = idaoproduct.findProduct(o.getSchemeName());
			long schemeid = Long.parseLong((scheme_id));
			Stockscheme stock = idaooffer.findProductId(schemeid);
			int value = Integer.parseInt(o.getValue());

			if (p != null) {

				if (p.getProductId().equalsIgnoreCase(Product_id) && o.getType().equalsIgnoreCase("buyandget")) {

					if (((value + 1) * qty) <= stock.getStock() - 1) {
						actual_price = price1 * qty;
						qty = qty + (value * qty);

						ps.setActual_price(actual_price);
						ps.setQty(qty);
					} else {

					}
				} else if ((!(p.getProductId().equalsIgnoreCase(Product_id)))
						&& (o.getType().equalsIgnoreCase("buyandget"))) {
					ProductSold ps2 = new ProductSold();
					ps2.setProduct_id(p.getProductId());
					ps2.setPrice(p.getProductCost());
					ps2.setActual_price(0);
					ps2.setProduct_name(p.getProductName());
					ps2.setQty(Integer.parseInt(o.getValue()) * qty);
					ps2.setScheme_id(scheme_id);
					ps2.setUser_id(user);
					ps.setActual_price(price1 * qty);
					ps.setQty(qty);
					list_ps.add(ps2);
				}
			} else {
				actual_price = price1 * value * 0.01F;
				actual_price = (price1 - actual_price) * qty;
				ps.setQty(qty);
				ps.setActual_price(actual_price);
			}
		}
		ps.setProduct_name(p_new.getProductName());
		ps.setProduct_id(Product_id);
		ps.setPrice(price1);
		ps.setScheme_id(scheme_id);
		ps.setUser_id(user);
		list_ps.add(ps);
		return list_ps;

	}
}

/*
 * @Transactional public void findSimilarProducts(String productId, ModelMap
 * map) { // TODO Auto-generated method stub Product
 * product=idaoproduct.findByProductId(productId); String[]
 * selected_prod_tags=product.getProductTag().split(" "); List<Product>
 * prod_list=idaoproduct.findByCategory(product.getCategory());
 * List<ImageProdId> mediaList=new ArrayList<ImageProdId>();
 * 
 * for(Product p:prod_list){
 * 
 * if(p.getProductId().equalsIgnoreCase(product.getProductId())){
 * 
 * continue; } String similar_tags=p.getProductTag(); for(String
 * tag:selected_prod_tags){ if(similar_tags.contains(tag)){ String imagePath=new
 * String(); imagePath=ipaddress; ImageProdId temp=new ImageProdId();
 * 
 * 
 * List<Media> similar_product=idaomedia.findByMediaTypeAndProduct("image",p);
 * 
 * 
 * Media similar_product_media=similar_product.get(0);
 * imagePath=imagePath.concat(similar_product_media.getMediaPath());
 * temp.setImgPath(imagePath);
 * temp.setProdId(similar_product_media.getProduct().getProductId());
 * mediaList.add(temp); break; } } } map.put("imageListSize",mediaList.size());
 * map.put("productList",mediaList); //return map; }
 */
