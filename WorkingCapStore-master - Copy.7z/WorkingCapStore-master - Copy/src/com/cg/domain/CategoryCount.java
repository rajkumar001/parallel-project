package com.cg.domain;

public class CategoryCount  {
	String categoryname;
	String categoryId;
	int categorycount;
	public String getCategoryname() {
		return categoryname;
	}
	public void setCategoryname(String categoryname) {
		this.categoryname = categoryname;
	}
	public String getCategoryId() {
		return categoryId;
	}
	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}
	public int getCategorycount() {
		return categorycount;
	}
	public void setCategorycount(int categorycount) {
		this.categorycount = categorycount;
	}

}
