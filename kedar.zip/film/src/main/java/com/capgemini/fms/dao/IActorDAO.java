package com.capgemini.fms.dao;

import java.util.List;

import com.capgemini.fms.bean.Actor;


public interface IActorDAO {

	public Actor save(Actor actor);

	public List<Actor> searchByName(String firstName, String lastName);

	public List<Actor> searchByAge(byte age);

	public Boolean modifyActor(int id,Actor actor);

	public Boolean deleteActor(String firstName, String lastName);
}
