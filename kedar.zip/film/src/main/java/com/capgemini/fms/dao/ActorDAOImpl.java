package com.capgemini.fms.dao;

import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;

import com.capgemini.fms.bean.Actor;
import com.capgemini.fms.bean.Album;
import com.capgemini.fms.bean.Image;
import com.capgemini.fms.dao.IActorDAO;

public class ActorDAOImpl implements IActorDAO {

	private EntityManager em;

	public ActorDAOImpl(EntityManager em) {
		this.em = em;
	}

	public Actor save(Actor actor) {
		try {
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a where a.firstName like :nam", Actor.class);
			Actor ac = query.setParameter("nam", actor.getFirstName()).getSingleResult();

			if (ac == null) {
				em.persist(actor);
				return actor;
			} else
				return ac;
		} catch (NoResultException e) {
			em.persist(actor);
			return actor;
		}
	}

	public List<Actor> searchByName(String firstName, String lastName) {

		TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l",
				Actor.class);
		List<Actor> list = query.setParameter("f", firstName).setParameter("l", lastName).getResultList();
		return list;

	}

	public List<Actor> searchByAge(byte age) {

		return null;
	}

	public Boolean modifyActor(int id, Actor actor) {

		Actor savedActor = em.find(Actor.class, id);
		savedActor.setAlbum(actor.getAlbum());
		savedActor.setFirstName(actor.getFirstName());
		savedActor.setLastName(actor.getLastName());
		savedActor.setGender(actor.getGender());
		savedActor.setCreateDate(actor.getCreateDate());
		savedActor.setFilm(actor.getFilm());
		em.persist(actor);
		return true;
	}

	public Boolean deleteActor(String firstName, String lastName) {
		try {
			TypedQuery<Actor> query = em.createQuery("SELECT a FROM Actor a WHERE a.firstName =:f AND a.lastName =:l",
					Actor.class);
			Actor actor = query.setParameter("f", firstName).setParameter("l", lastName).getSingleResult();
			actor.setDeleteDate(new Date());
			em.persist(actor);
			return true;
		} catch (Exception e) {
			return false;
		}
	}

	public List<Actor> getActors() {

		try {
			TypedQuery<Actor> query = em.createQuery("Select a from Actor a", Actor.class);
			List<Actor> ac = query.getResultList();

			return ac;
		} catch (NoResultException e) {
			return null;
		}

	}

	public Album addAlbum(Album album) {

		em.persist(album);
		System.out.println("album save");
		return album;
	}

	public Image addImage(Image img) {

		try {

			em.persist(img);
			return img;

		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}

	}

}
